import { useQuery } from '@tanstack/react-query';
import { where } from 'firebase/firestore';
import { APP_CONFIG } from '@/shared/config/appConfig';
import { orderRepository } from '@/shared/services/firestore/orderRepository';
import { userRepository } from '@/shared/services/firestore/userRepository';
import { subscriptionRepository } from '@/shared/services/firestore/subscriptionRepository';

export interface AdminMetrics {
  totalCustomers: number;
  activeSubscriptions: number;
  todayOrders: {
    total: number;
    delivered: number;
    pending: number;
  };
}

export function useAdminDashboardMetrics() {
  const today = new Intl.DateTimeFormat(APP_CONFIG.dateFormat.system, { 
    timeZone: APP_CONFIG.timezone 
  }).format(new Date());

  return useQuery({
    queryKey: ['admin', 'dashboard', 'metrics', today],
    queryFn: async (): Promise<AdminMetrics> => {
      // 1. Total Customers
      const totalCustomers = await userRepository.count(where('role', '==', 'customer'));

      // 2. Active Subscriptions
      const activeSubscriptions = await subscriptionRepository.count(where('status', '==', 'active'));

      // 3. Today's Orders
      const orders = await orderRepository.getByDate(today);
      const totalOrders = orders.length;
      const deliveredOrders = orders.filter(o => o.status === 'delivered').length;
      const pendingOrders = totalOrders - deliveredOrders;

      return {
        totalCustomers,
        activeSubscriptions,
        todayOrders: {
          total: totalOrders,
          delivered: deliveredOrders,
          pending: pendingOrders,
        }
      };
    },
    refetchInterval: 60000, // Auto-refresh every 60 seconds
  });
}
